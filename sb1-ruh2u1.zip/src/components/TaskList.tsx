import React from 'react';
import { Task, Category } from '../types';
import { Calendar, CheckCircle2, Circle, Trash2 } from 'lucide-react';

interface TaskListProps {
  tasks: Task[];
  categories: Category[];
  onToggleTask: (taskId: string) => void;
  onDeleteTask: (taskId: string) => void;
}

const categoryColors = {
  red: { bg: 'bg-red-100', text: 'text-red-800', border: 'border-red-200' },
  blue: { bg: 'bg-blue-100', text: 'text-blue-800', border: 'border-blue-200' },
  green: { bg: 'bg-green-100', text: 'text-green-800', border: 'border-green-200' },
  purple: { bg: 'bg-purple-100', text: 'text-purple-800', border: 'border-purple-200' },
  yellow: { bg: 'bg-yellow-100', text: 'text-yellow-800', border: 'border-yellow-200' },
};

const TaskList: React.FC<TaskListProps> = ({
  tasks,
  categories,
  onToggleTask,
  onDeleteTask,
}) => {
  const isNearDueDate = (dueDate: string) => {
    const due = new Date(dueDate);
    const now = new Date();
    const diffDays = Math.ceil((due.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return diffDays <= 2 && diffDays >= 0;
  };

  const getCategoryColor = (categoryId: string) => {
    const category = categories.find(c => c.id === categoryId);
    return category ? categoryColors[category.color as keyof typeof categoryColors] : categoryColors.blue;
  };

  return (
    <div className="space-y-4">
      {tasks.map((task) => {
        const categoryColor = getCategoryColor(task.categoryId);
        const category = categories.find(c => c.id === task.categoryId);
        const nearDueDate = isNearDueDate(task.dueDate);

        return (
          <div
            key={task.id}
            className={`p-4 rounded-lg border ${
              nearDueDate ? 'bg-red-50 border-red-200' : 'bg-white border-gray-200'
            } shadow-sm transition-all hover:shadow-md`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3 flex-1">
                <button
                  onClick={() => onToggleTask(task.id)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  {task.completed ? (
                    <CheckCircle2 className="w-6 h-6 text-green-500" />
                  ) : (
                    <Circle className="w-6 h-6" />
                  )}
                </button>
                <div className="flex-1">
                  <p className={`text-gray-800 ${task.completed ? 'line-through text-gray-500' : ''}`}>
                    {task.title}
                  </p>
                  <div className="flex items-center space-x-2 mt-2">
                    <span
                      className={`text-sm px-2 py-1 rounded-full ${categoryColor.bg} ${categoryColor.text}`}
                    >
                      {category?.name}
                    </span>
                    <div className="flex items-center text-sm text-gray-500">
                      <Calendar className="w-4 h-4 mr-1" />
                      {new Date(task.dueDate).toLocaleDateString('ja-JP')}
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => onDeleteTask(task.id)}
                  className="text-gray-400 hover:text-red-500 transition-colors"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default TaskList;