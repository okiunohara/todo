import React, { useState } from 'react';
import { Category } from '../types';
import { Plus, X } from 'lucide-react';

interface CategoryManagerProps {
  categories: Category[];
  onAddCategory: (category: Omit<Category, 'id'>) => void;
  onDeleteCategory: (categoryId: string) => void;
}

const colors = [
  { id: 'red', label: '赤' },
  { id: 'blue', label: '青' },
  { id: 'green', label: '緑' },
  { id: 'purple', label: '紫' },
  { id: 'yellow', label: '黄' },
];

const CategoryManager: React.FC<CategoryManagerProps> = ({
  categories,
  onAddCategory,
  onDeleteCategory,
}) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [selectedColor, setSelectedColor] = useState(colors[0].id);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName.trim()) return;

    onAddCategory({
      name: newCategoryName,
      color: selectedColor,
    });

    setNewCategoryName('');
    setSelectedColor(colors[0].id);
    setIsAdding(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-800">カテゴリー管理</h2>
        <button
          onClick={() => setIsAdding(true)}
          className="flex items-center px-3 py-1 text-sm text-blue-600 hover:text-blue-700"
        >
          <Plus className="w-4 h-4 mr-1" />
          追加
        </button>
      </div>

      {isAdding && (
        <form onSubmit={handleSubmit} className="p-4 bg-gray-50 rounded-lg space-y-3">
          <div>
            <label htmlFor="categoryName" className="block text-sm font-medium text-gray-700 mb-1">
              カテゴリー名
            </label>
            <input
              type="text"
              id="categoryName"
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="カテゴリー名を入力"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              色
            </label>
            <div className="flex space-x-2">
              {colors.map((color) => (
                <button
                  key={color.id}
                  type="button"
                  onClick={() => setSelectedColor(color.id)}
                  className={`w-8 h-8 rounded-full border-2 ${
                    selectedColor === color.id ? 'border-gray-600' : 'border-transparent'
                  } ${`bg-${color.id}-500`}`}
                  title={color.label}
                />
              ))}
            </div>
          </div>
          <div className="flex justify-end space-x-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-3 py-1 text-sm text-gray-600 hover:text-gray-800"
            >
              キャンセル
            </button>
            <button
              type="submit"
              className="px-3 py-1 text-sm text-white bg-blue-600 rounded-md hover:bg-blue-700"
            >
              追加
            </button>
          </div>
        </form>
      )}

      <div className="space-y-2">
        {categories.map((category) => (
          <div
            key={category.id}
            className="flex items-center justify-between p-2 bg-white rounded-md border border-gray-200"
          >
            <div className="flex items-center space-x-2">
              <div className={`w-4 h-4 rounded-full bg-${category.color}-500`} />
              <span className="text-gray-800">{category.name}</span>
            </div>
            <button
              onClick={() => onDeleteCategory(category.id)}
              className="text-gray-400 hover:text-red-500"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategoryManager;