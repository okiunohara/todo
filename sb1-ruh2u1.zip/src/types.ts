export interface Task {
  id: string;
  title: string;
  categoryId: string;
  dueDate: string;
  completed: boolean;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  color: string;
}

export type CategoryColors = Record<string, { bg: string; text: string; border: string }>;